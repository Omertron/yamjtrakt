Licence
=======

This work is licensed under a
Creative Commons Attribution-ShareAlike 3.0 Unported License.
http://creativecommons.org/licenses/by-sa/3.0/

You are free:
to Share — to copy, distribute and transmit the work
to Remix — to adapt the work
to make commercial use of the work

Under the following conditions:

Attribution — You must attribute the work in the manner specified by the author
               or licensor (but not in any way that suggests that they endorse
               you or your use of the work).
Share Alike — If you alter, transform, or build upon this work, you may
               distribute the resulting work only under the same or similar
               license to this one.
