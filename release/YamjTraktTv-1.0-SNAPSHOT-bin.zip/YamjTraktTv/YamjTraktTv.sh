#!/bin/sh
echo YAMJ Trakt.tv App
echo Build Date: 2012-03-30 15:32:40
echo Version: 1.0-SNAPSHOT
java -jar YamjTraktTv-1.0-SNAPSHOT-jar-with-dependencies.jar