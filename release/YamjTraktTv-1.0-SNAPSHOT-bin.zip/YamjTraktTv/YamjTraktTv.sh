#!/bin/sh
echo YAMJ Trakt.tv App
echo Build Date: 2012-03-31 16:36:34
echo Version: 1.0-SNAPSHOT
java -jar YamjTraktTv-1.0-SNAPSHOT-jar-with-dependencies.jar