#!/bin/sh
echo YAMJ Trakt.tv App
echo Version: 1.0
echo Build Date: 2012-05-16 20:31:31
echo Build: 86ed22a9
java -jar YamjTraktTv-1.0-jar-with-dependencies.jar