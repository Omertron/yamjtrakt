YAMJ Trakt App
==============

This *very* simple GUI can be used to upload your existing YAMJ library to [Trakt.tv](http://trakt.tv)

The movies and tv shows will be read from the CompleteMovies.xml file in your
jukebox and uploaded to the website. If you have the shows marked as watched,
then they will be marked as "seen" on Trakt.tv too.

Any files not marked as watched will just be added to your collection.

Download
--------
You can download the latest version [from here](https://github.com/Omertron/yamjtrakt/tree/master/release)
Although this will change to [MediaPlayerSite](http://mediaplayersite.com/) at some point

Project Documentation
---------------------
The automatically generated documentation can be found [HERE](http://omertron.github.com/yamjtrakt/)
