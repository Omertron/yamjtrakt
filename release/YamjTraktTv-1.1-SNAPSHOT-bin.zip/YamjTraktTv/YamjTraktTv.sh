#!/bin/sh
echo YAMJ Trakt.tv App
echo Version: 1.1-SNAPSHOT
echo Build Date: 2013-01-27 18:37:52
java -jar YamjTraktTv-1.1-SNAPSHOT-jar-with-dependencies.jar