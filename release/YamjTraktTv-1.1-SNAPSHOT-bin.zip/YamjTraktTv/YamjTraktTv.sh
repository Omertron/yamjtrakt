#!/bin/sh
echo YAMJ Trakt.tv App
echo Version: 1.1-SNAPSHOT
echo Build Date: 2012-05-16 21:43:52
echo Build: 82a9b386
java -jar YamjTraktTv-1.1-SNAPSHOT-jar-with-dependencies.jar