#!/bin/sh
echo YAMJ Trakt.tv App
echo Version: 1.1-SNAPSHOT
echo Build Date: 2014-03-05 14:29:06
java -jar YamjTraktTv-1.1-SNAPSHOT-jar-with-dependencies.jar