#!/bin/sh
echo YAMJ Trakt.tv App
echo Version: 1.1.3
echo Build Date: 2014-03-19 14:15:16
java -jar YamjTraktTv-1.1.3-jar-with-dependencies.jar