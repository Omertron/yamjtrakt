#!/bin/sh
echo YAMJ Trakt.tv App
echo Version: 1.1.5
echo Build Date: 2014-03-27 10:40:28
java -jar YamjTraktTv-1.1.5-jar-with-dependencies.jar